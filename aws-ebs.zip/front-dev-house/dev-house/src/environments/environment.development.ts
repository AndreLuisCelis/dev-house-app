export const environment = {
    production: false,
    baseUrl: process.env["API_URL"] 
};
