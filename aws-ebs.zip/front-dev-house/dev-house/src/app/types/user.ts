export interface User {
    email: string;
    _id?: string
}
